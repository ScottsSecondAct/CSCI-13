package com.s1scottd.WeatherForecastApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherForecastAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
